import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class BMICalculatorGUI extends JFrame implements ActionListener {
    private JTextField heightField, weightField, resultField;

    public BMICalculatorGUI() {
        setTitle("BMI Calculator");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 5, 5)); // Adjusting gap between components

        JLabel heightLabel = new JLabel("Height (m):");
        heightField = new JTextField();
        JLabel weightLabel = new JLabel("Weight (kg):");
        weightField = new JTextField();
        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(this);
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        resultField = new JTextField();
        resultField.setEditable(false);

        // Adding components to the panel
        panel.add(heightLabel);
        panel.add(heightField);
        panel.add(weightLabel);
        panel.add(weightField);
        panel.add(calculateButton);
        panel.add(clearButton);
        panel.add(new JLabel("BMI:"));
        panel.add(resultField);

        // Adding panel to the frame's content pane
        getContentPane().add(panel, BorderLayout.CENTER);

        // Centering the frame on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Calculate")) {
            calculateBMI();
        } else if (e.getActionCommand().equals("Clear")) {
            clearFields();
        }
    }

    private void calculateBMI() {
        try {
            double height = Double.parseDouble(heightField.getText());
            double weight = Double.parseDouble(weightField.getText());
            double bmi = weight / (height * height);
            resultField.setText(String.format("%.2f", bmi));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for height and weight.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        heightField.setText("");
        weightField.setText("");
        resultField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BMICalculatorGUI());
    }
}